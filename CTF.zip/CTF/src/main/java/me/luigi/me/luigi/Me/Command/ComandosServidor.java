package me.luigi.me.luigi.Me.Command;

import net.minecraft.server.v1_12_R1.ItemFishingRod;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.entity.Skeleton;
import org.bukkit.inventory.ItemStack;

public class ComandosServidor implements CommandExecutor {

    public boolean onCommand(CommandSender s, Command c, String label, String[] args){
        if(!(s instanceof Player));
        Player p = (Player) s;

        if(c.getName().equalsIgnoreCase("NPC")){
            if(args.length == 0){
                p.sendMessage(ChatColor.GREEN+"ELE FOI SPAWNADO!");
                NpcSpawn(p);
            }
        }
        return false;
    }


    private void NpcSpawn(Player p){
        Skeleton skeleton = (Skeleton) p.getWorld().spawnEntity(p.getLocation(), EntityType.SKELETON);
        skeleton.setCustomNameVisible(true);
        skeleton.setCustomName(ChatColor.GREEN+"JORGE");
        skeleton.setAI(false);
        skeleton.setInvulnerable(false);
        skeleton.isGlowing();
        ItemStack Item = new ItemStack(Material.FISHING_ROD, 1);
        skeleton.getEquipment().setItemInMainHandDropChance(100);
        skeleton.getEquipment().setItemInMainHand(Item);
        skeleton.setFireTicks(0);

    }
}