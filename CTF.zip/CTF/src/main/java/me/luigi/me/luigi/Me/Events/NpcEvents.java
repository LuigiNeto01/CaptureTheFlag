package me.luigi.me.luigi.Me.Events;

import org.bukkit.ChatColor;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.entity.Skeleton;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.event.player.PlayerTeleportEvent;

public class NpcEvents implements Listener {
    public void NpcInteract(PlayerTeleportEvent e){


    }
}
