package me.luigi.me.luigi.Me.Events;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.entity.Skeleton;
import org.bukkit.entity.Villager;
import org.bukkit.event.Event;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerEggThrowEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.event.player.PlayerItemConsumeEvent;
import org.bukkit.inventory.Inventory;

public class PlayerEvents implements Listener {
    @EventHandler
   public void Soup(PlayerDropItemEvent e){
       Player p = e.getPlayer();
       e.setCancelled(true);
   }
   @EventHandler
    public void NpcInteract(PlayerInteractEntityEvent e){
        Player p = e.getPlayer();
        if(!(e.getRightClicked() instanceof Skeleton)) return;
        Skeleton s = (Skeleton) e.getRightClicked();
        if(s.getCustomName() == null || s.getCustomName().equalsIgnoreCase("JORGE")) return;
        e.setCancelled(true);
    }

    }


