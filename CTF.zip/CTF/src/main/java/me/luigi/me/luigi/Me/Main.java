package me.luigi.me.luigi.Me;

import me.luigi.me.luigi.Me.Command.ComandosServidor;
import me.luigi.me.luigi.Me.Events.NpcEvents;
import me.luigi.me.luigi.Me.Events.PlayerEvents;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

public final class Main extends JavaPlugin {

    @Override
    public void onEnable() {
        Bukkit.getConsoleSender().sendMessage(ChatColor.GREEN + "TO LIGADO");
        Bukkit.getPluginManager().registerEvents(new PlayerEvents(), this);
        Bukkit.getPluginManager().registerEvents(new NpcEvents(), this);
        startschedule();
        RegistrarCommands();
    }

private void RegistrarCommands(){
        getCommand("NPC").setExecutor(new ComandosServidor());
}


    //Menssage repeting showing my discord!

public void startschedule(){
        Bukkit.getScheduler().scheduleSyncRepeatingTask(this, () -> {
            Bukkit.getConsoleSender().sendMessage(ChatColor.GREEN+"Você ja conhece a lagoinha? se não conheça ela pelo link do "+ ChatColor.BLUE+"DISCORD: "+ChatColor.WHITE+"https://discord.gg/PSvrxnBxBd"+ChatColor.GREEN+" Agora é só entrar e socializar-se!");
            for (Player p : Bukkit.getOnlinePlayers()) {
                p.sendMessage(ChatColor.GREEN + "Você ja conhece a lagoinha? se não conheça ela pelo link do " + ChatColor.BLUE + "DISCORD: " + ChatColor.WHITE + "https://discord.gg/PSvrxnBxBd" + ChatColor.GREEN+" Agora é só entrar e socializar-se!");
            }
        }, 0, 20 * 30 * 5);
}

    @Override
    public void onDisable() {
        Bukkit.getConsoleSender().sendMessage(ChatColor.RED+"TO DESLIGADO");
    }
}
